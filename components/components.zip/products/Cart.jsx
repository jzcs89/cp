import React from 'react'

// export default class Product extends Component {
export default function Cart() {


    return (

        <
        >

        <
        />

    )
}
