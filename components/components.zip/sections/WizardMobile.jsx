import React from 'react'
import Link from 'next/link'

export default function WizardMobile(props) {


    return (

        <>
        <div style={{
            height: '100vh',
            width: '100vh',
        }}>
            <Link href="/wizard"><a></a></Link>
        </div>
        </>

    )
}