import React, { useMemo, useState } from 'react';



export default function NewMenuProfile(props) {
  
    return (
        <>
        {/* <SideBar /> */}
        {/* {props.login ?
           <SideBar />
        : 
        <SidebarGuest />
        } */}
        </>

    );
}
